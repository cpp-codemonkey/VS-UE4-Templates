// Fill out your copyright notice in the Description page of Project Settings.


#include "$safeitemname$.h"

U$safeitemname$::U$safeitemname$()
{
	bNotifyBecomeRelevant = true;
	NodeName = TEXT("");
}

void U$safeitemname$::OnBecomeRelevant(UBehaviorTreeComponent& owner_comp, uint8* node_memory)
{
	Super::OnBecomeRelevant(owner_comp, node_memory);
}
