#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/Services/BTService_BlackboardBase.h"
#include "$safeitemname$.generated.h"

UCLASS()
class _API U$safeitemname$ : public UBTService_BlackboardBase
{
	GENERATED_BODY()
public:
	U$safeitemname$();
	void OnBecomeRelevant(UBehaviorTreeComponent& owner_comp, uint8* node_memory) override;
};
