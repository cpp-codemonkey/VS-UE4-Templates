#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "$safeitemname$.generated.h"

/**
 * 
 */
UCLASS()
class _API U$safeitemname$ : public UObject
{
	GENERATED_BODY()
public:	
	U$safeitemname$();
};
