#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "$safeitemname$.generated.h"


UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class _API U$safeitemname$ : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	U$safeitemname$();

	// Called every frame
	void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

protected:
	// Called when the game starts
	void BeginPlay() override;
};
