#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "$safeitemname$.generated.h"


UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class _API U$safeitemname$ : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	U$safeitemname$();

	// Called every frame
	void TickComponent(float const delta_time, ELevelTick const tick_type, FActorComponentTickFunction* const this_tick_function) override;

protected:
	// Called when the game starts
	void BeginPlay() override;
};
