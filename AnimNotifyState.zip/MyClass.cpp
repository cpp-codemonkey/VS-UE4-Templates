// Fill out your copyright notice in the Description page of Project Settings.


#include "$safeitemname$.h"

void U$safeitemname$::NotifyBegin(USkeletalMeshComponent* const mesh, UAnimSequenceBase* const animation, float const total_duration)
{
}

void U$safeitemname$::NotifyTick(USkeletalMeshComponent* const mesh, UAnimSequenceBase* const animation, float const frame_delta_time)
{
}

void U$safeitemname$::NotifyEnd(USkeletalMeshComponent* const mesh, UAnimSequenceBase* const animation)
{
}
