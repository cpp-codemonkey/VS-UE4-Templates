#pragma once


#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "$safeitemname$.generated.h"

UCLASS()
class _API U$safeitemname$ : public UAnimNotifyState
{
	GENERATED_BODY()
	
public:	
	void NotifyBegin(USkeletalMeshComponent* const mesh, UAnimSequenceBase* const animation, float const total_duration) override;
	void NotifyTick(USkeletalMeshComponent* const mesh, UAnimSequenceBase* const animation, float const frame_delta_time) override;
	void NotifyEnd(USkeletalMeshComponent* const mesh, UAnimSequenceBase* const animation) override;
};