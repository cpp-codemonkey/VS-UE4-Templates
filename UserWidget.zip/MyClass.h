#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Runtime/UMG/Public/Components/Button.h"
#include "$safeitemname$.generated.h"

UCLASS()
class _API U$safeitemname$ : public UUserWidget
{
	GENERATED_BODY()
public:
	void NativeConstruct() override;
protected:
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
	UButton* ClickMeButton = nullptr;
private:
	UFUNCTION()
	void ButtonClicked();
};