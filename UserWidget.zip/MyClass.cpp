#include "$safeitemname$.h"


void U$safeitemname$::NativeConstruct()
{
	if (ClickMeButton)
	{
		ClickMeButton->OnClicked.AddDynamic(this, &U$safeitemname$::ButtonClicked);
	}
}

void U$safeitemname$::ButtonClicked()
{
}
