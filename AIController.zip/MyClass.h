#pragma once

#include "CoreMinimal.h"
#include "AIController.h"
#include "$safeitemname$.generated.h"

UCLASS()
class _API A$safeitemname$ : public AAIController
{
	GENERATED_BODY()
public:	
	A$safeitemname$(FObjectInitializer const& object_initializer = FObjectInitializer::Get());
	void BeginPlay() override;
	void OnPossess(APawn* const pawn) override;
};