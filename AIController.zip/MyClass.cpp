// Fill out your copyright notice in the Description page of Project Settings.


#include "$safeitemname$.h"

A$safeitemname$::A$safeitemname$(FObjectInitializer const& object_initializer)
{

}

void A$safeitemname$::BeginPlay()
{
}

void A$safeitemname$::OnPossess(APawn* const pawn)
{
}

