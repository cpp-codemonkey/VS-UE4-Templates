#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Pawn.h"
#include "$safeitemname$.generated.h"

UCLASS()
class _API A$safeitemname$ : public APawn
{
	GENERATED_BODY()

public:
	// Sets default values for this pawn's properties
	A$safeitemname$();

	// Called every frame
	void Tick(float const delta_time) override;

	// Called to bind functionality to input
	void SetupPlayerInputComponent(class UInputComponent* const player_input_component) override;

protected:
	// Called when the game starts or when spawned
	void BeginPlay() override;
};
