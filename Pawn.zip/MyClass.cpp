#include "$safeitemname$.h"

// Sets default values
A$safeitemname$::A$safeitemname$()
{
 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void A$safeitemname$::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void A$safeitemname$::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

// Called to bind functionality to input
void A$safeitemname$::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

