#pragma once

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "$safeitemname$.generated.h"

UCLASS()
class _API A$safeitemname$ : public AHUD
{
	GENERATED_BODY()
public:
	A$safeitemname$();
	void BeginPlay() override;
};
