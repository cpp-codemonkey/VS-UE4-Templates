#include "$safeitemname$.h"

A$safeitemname$::A$safeitemname$()
{

}

void A$safeitemname$::BeginPlay()
{
	Super::BeginPlay();
}
