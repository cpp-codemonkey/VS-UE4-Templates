#include "$safeitemname$.h"

A$safeitemname$::A$safeitemname$()
{
	OnActorBeginOverlap.AddDynamic(this, &A$safeitemname$::on_overlap_begin);
	OnActorEndOverlap.AddDynamic(this, &A$safeitemname$::on_overlap_end);
}

void A$safeitemname$::BeginPlay()
{
	Super::BeginPlay();
}

void A$safeitemname$::on_overlap_begin(AActor* const overlapped_actor, AActor* const other_actor)
{
}

void A$safeitemname$::on_overlap_end(AActor* const overlapped_actor, AActor* const other_actor)
{
}
