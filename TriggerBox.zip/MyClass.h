#pragma once

#include "CoreMinimal.h"
#include "Engine/TriggerBox.h"
#include "$safeitemname$.generated.h"

UCLASS()
class _API A$safeitemname$ : public ATriggerBox
{
	GENERATED_BODY()
public:
	A$safeitemname$();
protected:
	void BeginPlay() override;
private:
	UFUNCTION()
	void on_overlap_begin(class AActor* const overlapped_actor, class AActor* const other_actor);

	UFUNCTION()
	void on_overlap_end(class AActor* const overlapped_actor, class AActor* const other_actor);

};
