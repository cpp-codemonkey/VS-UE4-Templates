#pragma once


#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "$safeitemname$.generated.h"

UCLASS()
class _API A$safeitemname$ : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	A$safeitemname$();

	// Called every frame
	virtual void Tick(float const delta_time) override;
protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
};