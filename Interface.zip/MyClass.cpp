#include "$safeitemname$.h"

// Add default functionality here for any IMyInterface functions that are not pure virtual.
