// Fill out your copyright notice in the Description page of Project Settings.


#include "$safeitemname$.h"

// Sets default values
A$safeitemname$::A$safeitemname$()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void A$safeitemname$::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void A$safeitemname$::Tick(float const delta_time)
{
	Super::Tick(delta_time);

}

// Called to bind functionality to input
void A$safeitemname$::SetupPlayerInputComponent(UInputComponent* const player_input_component)
{
	Super::SetupPlayerInputComponent(player_input_component);

}