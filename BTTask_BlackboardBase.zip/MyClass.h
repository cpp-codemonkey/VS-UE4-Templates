#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/Tasks/BTTask_BlackboardBase.h"
#include "$safeitemname$.generated.h"

/**
 * 
 */
UCLASS()
class _API U$safeitemname$ : public UBTTask_BlackboardBase
{
	GENERATED_BODY()
public:
	U$safeitemname$(FObjectInitializer const& object_initializer);

	EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& owner_comp, uint8* node_memory) override;
};
