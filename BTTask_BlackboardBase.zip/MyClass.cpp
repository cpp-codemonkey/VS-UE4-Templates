// Fill out your copyright notice in the Description page of Project Settings.


#include "$safeitemname$.h"

U$safeitemname$::U$safeitemname$(FObjectInitializer const& object_initializer)
{
	NodeName = TEXT("");
}

EBTNodeResult::Type U$safeitemname$::ExecuteTask(UBehaviorTreeComponent& owner_comp, uint8* node_memory)
{
	return EBTNodeResult::Succeeded;
}
