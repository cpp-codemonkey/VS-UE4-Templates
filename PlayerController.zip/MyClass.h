#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "$safeitemname$.generated.h"

UCLASS()
class _API A$safeitemname$ : public APlayerController
{
	GENERATED_BODY()
public:
	A$safeitemname$();
};
