#include "$safeitemname$.h"

// Sets default values
A$safeitemname$::A$safeitemname$()
{

}