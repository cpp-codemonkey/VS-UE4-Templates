#include "$safeitemname$.h"

A$safeitemname$::A$safeitemname$()
{

}