#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "$safeitemname$.generated.h"

UCLASS()
class _API A$safeitemname$ : public AGameModeBase
{
	GENERATED_BODY()
public:
	A$safeitemname$();
};
