#pragma once

#include "CoreMinimal.h"
#include "Engine/GameInstance.h"
#include "$safeitemname$.generated.h"

UCLASS()
class _API U$safeitemname$ : public UGameInstance
{
	GENERATED_BODY()
public:
	U$safeitemname$();
};
