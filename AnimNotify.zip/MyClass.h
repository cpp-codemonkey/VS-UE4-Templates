#pragma once


#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "$safeitemname$.generated.h"

UCLASS()
class _API U$safeitemname$ : public UAnimNotify
{
	GENERATED_BODY()
	
public:	
	void Notify(USkeletalMeshComponent* const mesh, UAnimSequenceBase* const animation) override;
};