// Fill out your copyright notice in the Description page of Project Settings.


#include "$safeitemname$.h"

// Sets default values
void U$safeitemname$::Notify(USkeletalMeshComponent* const mesh, UAnimSequenceBase* const animation)
{
}